# Manual de usuario

Para ingresar a la plataforma de cotización de contratos de prepago ingresa al siguiente link:
[https://prepago.elevapp.io/login](https://prepago.elevapp.io/login)

Te llevará a una web donde podrás ingresar tus datos de identificación.

Email: Ingresa tu email para ingresar a windows.
Contraseña: Ingresa la contraseña de windows.

*En el ingreso de datos de campo abierto, considerar el formato de ingreso que dicta el ejemplo dentro de la casilla.

Finalmente pincha en el botón Ingresar para comenzar a cotizar.

Antes de comenzar ingresa tu teléfono de contacto y selecciona sucursal.

*En el ingreso de datos de campo abierto, considerar el formato de ingreso que dicta el ejemplo dentro de la casilla.

### ¡MUY IMPORTANTE!

1. Al cotizar a través de la plataforma ELEVA, NO DEBEN completar posteriormente el
formulario de ventas. Eliminamos ese trámite y sus remuneraciones variables estarán calculadas a partir del código interno de SAP que ingresaron en la plataforma ELEVA al momento de hacer Login. *Si ingresan el formulario por ventas realizadas a través del flujo ELEVA, traerá inconvenientes técnicos en la administración y asignación de contratos para el área de servicios.
2. Felipe Jacob estará a disposición para resolver cualquier duda que tengan sobre la
implementación de esta solución. No duden en contactarlo por teams, mails o directamente a su número de teléfono. Teléfono: +56 9 85309829

Para comenzar el proceso de cotización, debes ingresar la patente o chasis del vehículo para el cuál quieres cotizar el prepago. No debes ingresar guión en la patente.

En segundo lugar, la sucursal que muestra la plataforma por defecto es donde normalmente atiende el asesor, en caso que el vehículo se atienda a futuro en otra sucursal debes cambiarla en esta misma pantalla.

Recuerda que al cambiar la sucursal puede afectar el precio del servicio que se quiere contratar.

Junto con seleccionar la nueva sucursal, debes hacer check en la casilla que declara el conocimiento del cliente de este cambio de sucursal.

En tercer lugar, debes ingresar la mantención a la cuál viene el vehículo. Es muy importante que el valor ingresado corresponda al de una mantención, de lo contrario no se reconocerá un paquete asignado.

A continuación, aparecerán los paquetes de prepago disponibles para el vehículo en cotización. Selecciona el paquete a cotizar y dale a siguente.

Como mejora, ahora podrás ver el valor de prepago de 2, 3, 4, 5 y 6 mantenciones. Recuerda que para servicios y en el caso de que el cliente se encuente en taller, estaremos incluyendo esta mantención dentro del cálculo.

A continuación, podrán ver un resumen de de la cotización. Este cuadro está pensado como una herramienta de venta en donde podrás ver de forma clara:
1.- El descuento que se realiza.
2.- Cual es el valor de mercado
de lo que está cotizando.
3.- El valor a pagar por parte
del cliente.
Dale click a enviar cotización.

Al enviar cotización por whatsapp al cliente, los datos estarán autorrellenados con los últimos datos del cliente si deseas actualizar algún dato puedes cambiarlo. Además podrás ingresar el número de OT en caso que lo tengas.

Al pasar a esta pantalla, se realizó el envío de la cotización y link de pago por whatsapp, el mensaje puede tardar hasta 40 segundos en llegar.

Al Ingresar en tu perfil encontrarán su información de inicio de sesión y en la parte inferior encontrarán el botón de “logout”. Al pulsarlo volverán a la pantalla anterior y podrán volver a hacer login.

Durante todo el flujo encontrarás este icono en donde se desplegará un formulario para contactar a nuestra área de soporte en caso de cualquier problema que tengas.

Por medio de este formulario podrás dejar todas las dudas que tengas y desde soporte Eleva lo resolveremos a la brevedad.

El cliente podrá ver la cotización en .pdf

Al pasar a esta pantalla, se realizó el envío de la cotización y link de pago por whatsapp, el mensaje puede tardar hasta 40 segundos en llegar.

El cliente podrá acceder a un botón de pago y finalizar la transacción directamente por webpay o khipu.

## ¿Cómo funciona Khipu?

El cliente podrá elegir entre hacer directamente la transferencia o hacerlo desde su banco.

Al elegir tu banco, el cliente debe ingresar el correo el electrónico donde quiere recibir el comprobante de pago de khipu.

El cliente debe elegir su banco (conectar con el banco puede tomar unos segundos).

El cliente debe ingresar los datos con lo que ingresa a su sesión en su banco (esto puede tomar
unos segundos).

NPS, al finalizar la cotización podrás contestar una encuesta de satisfacción, contestarla es muy importante para nosotros.

El cliente debe autorizar la transferencia con el dispositivo de seguridad que tenga con su banco.

¡Y listo!, el pago ha sido realizado con exito 🎉.