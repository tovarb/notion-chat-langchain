# Escalamiento problemas

## Problemas al ingresar a la página / plataforma de Eleva

¡Hola! Lamento que esté teniendo problemas para ingresar a la plataforma. A continuación, le brindaré algunas soluciones que puede intentar para resolver el problema.

Si no puede ingresar a la plataforma, le sugiero que revise la URL e intente nuevamente. Si esto no funciona, le sugiero que se comunique con Felipe Jacob por Teams, correo electrónico o directamente a su número de teléfono +56 9 85309829.

Si la plataforma o el sitio le indica que el usuario o la contraseña son incorrectos, le sugiero que revise si su correo electrónico tiene el código SAP. Si no es así o si no funciona, le sugiero que se comunique con Felipe Jacob por Teams, correo electrónico o directamente a su número de teléfono +56 9 85309829.

Si no puede acceder a la plataforma y no está seguro si está registrado, le sugiero que envíe la siguiente información a Felipe Jacob por Teams, correo electrónico o directamente a su número de teléfono +56 9 85309829:

1.- Nombre completo

2.- Rut

3.- Código

4.- Email

Espero que estas soluciones le ayuden a solucionar su problema. Si necesita más ayuda, no dude en ponerse en contacto con nosotros. ¡Gracias por utilizar nuestra plataforma!