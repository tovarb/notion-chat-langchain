# Escalamiento problemas

## Problemas al ingresar a la página / plataforma de Eleva

¡Hola! Lamento que esté teniendo problemas para ingresar a la plataforma. A continuación, le brindaré algunas soluciones que puede intentar para resolver el problema.

Si no puede ingresar a la plataforma, le sugiero que revise la URL e intente nuevamente. Si esto no funciona, le sugiero que se comunique con Felipe Jacob por Teams, correo electrónico o directamente a su número de teléfono +56 9 85309829.

Si la plataforma o el sitio le indica que el usuario o la contraseña son incorrectos, le sugiero que revise si su correo electrónico tiene el código SAP. Si no es así o si no funciona, le sugiero que se comunique con Felipe Jacob por Teams, correo electrónico o directamente a su número de teléfono +56 9 85309829.

Si no puede acceder a la plataforma y no está seguro si está registrado, le sugiero que envíe la siguiente información a Felipe Jacob por Teams, correo electrónico o directamente a su número de teléfono +56 9 85309829:

1.- Nombre completo

2.- Rut

3.- Código

4.- Email

Espero que estas soluciones le ayuden a solucionar su problema. Si necesita más ayuda, no dude en ponerse en contacto con nosotros. ¡Gracias por utilizar nuestra plataforma!

## Problemas durante la cotización

¡Hola! Entiendo que estás experimentando algunos problemas con tu patente, kilometraje, paquete, valores de mantenciones o resumen de cotización. Permíteme ayudarte a resolver cada uno de estos problemas.

Si tu patente no tiene prepago asignado, puede ser debido a varios motivos, como que el vehículo no esté creado en SAP, que el baumuster del vehículo no tenga un paquete asignado o puede haber problemas técnicos. En este caso, te sugiero que intentes nuevamente y si aún no puedes resolverlo, comunícate con Felipe Jacob por Teams, correo electrónico o directamente a su número de teléfono +56 9 85309829 para obtener ayuda adicional.

Si el kilometraje que ingresaste no coincide con las mantenciones de tu modelo, puede ser que hayas ingresado un número incorrecto. Te sugiero que vuelvas a ingresar el kilometraje y que lo valides para asegurarte de que sea el correcto. Otra posibilidad es que Baumuster no tenga el producto. Si aún tienes problemas, no dudes en contactar a nuestro equipo de soporte.

Si no puedes encontrar el paquete que necesitas para cotizar, puede haber una razón. Los paquetes pueden estar mal asignados a la configuración, por lo que te recomiendo que valides cómo se encuentran registrados en la plataforma. Si aún no puedes encontrar lo que necesitas, comunícate con nuestro equipo de soporte para obtener ayuda.

Si los valores de mantenciones están mal, como valores negativos, precios cero o simplemente no cuadran, te recomiendo que te comuniques con Felipe Jacob por Teams, correo electrónico o directamente a su número de teléfono +56 9 85309829 para que puedan resolver el problema.

Si el resumen de tu cotización muestra valores erróneos, como un valor de prepago mayor que sin prepago o valores que simplemente no cuadran, te sugiero que te comuniques con Felipe Jacob por Teams, correo electrónico o directamente a su número de teléfono +56 9 85309829 para que puedan resolver el problema.

Si no puedes enviar una cotización, puede haber varias razones. Puede ser que el rut que ingresaste no sea de un cliente del grupo Kaufmann, que el cliente esté moroso, que el servicio de mensajería esté caído o que estés intentando vender una categoría de producto no permitida por Eleva. Te sugiero que valides la información que ingresaste y que contactes a nuestro equipo de soporte si aún tienes problemas.

Espero que estas soluciones te hayan sido útiles. Si tienes alguna otra pregunta o problema, no dudes en contactarnos nuevamente. Estamos aquí para ayudarte en todo lo que necesites.

## Problemas con el envío

En relación al problema que está experimentando, puedo ayudarlo a resolverlo. Si usted está teniendo problemas para recibir su cotización, puede ser debido a que el número de teléfono del cliente fue ingresado en un formato no adecuado. Por favor, revise y verifique si el número de teléfono que ingresó tiene el formato correcto. 

Si usted está teniendo problemas para recibir el correo electrónico de cotización, le sugiero que espere algunos minutos, ya que puede haber un retraso en la entrega del correo electrónico. Si después de unos minutos no ha recibido el correo electrónico, por favor comuníquese con Felipe Jacob por Teams, correo electrónico o directamente a su número de teléfono +56 9 85309829 para obtener ayuda adicional.

En el caso de que no reciba el comprobante de pago del cliente, le sugiero que se ponga en contacto con el cliente para validar esta información. 

## Problemas con el pago

Entiendo que está teniendo problemas para realizar el pago de su compra. Si el cliente está teniendo problemas con su tarjeta de crédito, sugiera que intente con una tarjeta diferente para completar la transacción.

En caso de que el problema sea con la pasarela de pago, es posible que se deba a algún problema técnico o de conexión temporal en el sistema. En este caso, se sugiere validar la respuesta de la pasarela de pago para identificar la causa del problema y ofrecerle las opciones posibles para completar la transacción.

Si necesita más ayuda para resolver este problema, no dude en ponerse en contacto con Felipe Jacob por Teams, correo electrónico o directamente a su número de teléfono +56 9 85309829.

## Problemas al procesar el cupón

Si se tienen problemas con el procesamiento de su cupón, si no se procesó correctamente, o  el correo electrónico con la descripción del pago no se envió correctamente puede ser porque no se completó el formulario de venta correctamente . Le sugiero que intente nuevamente y, si aún tiene problemas, puede ponerse en contacto con Felipe Jacob por Teams, correo electrónico o directamente a su número de teléfono +56 9 85309829 para obtener ayuda adicional.

Si ha experimentado problemas con el robot, lo más probable es que se deba a un número interno incorrecto. Le sugiero que valide el número interno para asegurarse de que sea el correcto.

En cuanto al problema con el cupón pagado pero sin dinero en la cuenta del cliente, es posible que el cliente esté duplicado en el sistema CRM. 

Si necesita más ayuda para resolver cualquier problema, no dude en ponerse en contacto con Felipe Jacob por Teams, correo electrónico o directamente a su número de teléfono +56 9 85309829 para obtener apoyo adicional.