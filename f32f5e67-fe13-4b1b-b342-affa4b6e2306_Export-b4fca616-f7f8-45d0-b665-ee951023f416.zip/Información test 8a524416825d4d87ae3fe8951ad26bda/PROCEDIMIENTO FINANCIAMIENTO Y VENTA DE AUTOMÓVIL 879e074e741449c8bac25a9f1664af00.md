# PROCEDIMIENTO FINANCIAMIENTO Y VENTA DE AUTOMÓVILES NUEVOS Y SEMINUEVOS

1. OBJETIVO
Establecer el procedimiento para las ventas de automóviles nuevos y/o seminuevos para la red
de sucursales, con el propósito que se realicen en un marco debidamente regulado, acotando los
riesgos en las operaciones normales de ventas al contado y crédito.
2. ALCANCE
2.1. Gerente Comercial de Automóviles
2.2. Red de sucursales
2.3. Gerencia de créditos y seguros
2.4. Gerencia Administración de Ventas
3. RESPONSABILIDADES
3.1. Gerente Comercial Automóviles: Establecer Políticas Comerciales y según atribuciones
autorizar las formas de pago.
3.2. Gerente de Sucursal: Establecer un control a los precios de venta, velar por el nivel de
descuentos y volumen de negocios en cuanto a las metas establecidas.
3.3. Sub Gerente/Jefe de Administración/Encargados: Encargado de velar por el
cumplimiento del presente procedimiento.
3.4. Vendedor de Automóviles: Encargado de ofrecer los automóviles disponibles, de
acuerdo a las políticas vigentes.
3.5. Asistente Administrativo de Ventas: Encargado de la confección de la carpeta de venta,
seguimiento vehículos en retoma, consignaciones y concesiones.
3.6. Encargado Stock de Automóviles Nuevos/Seminuevos: Planificar y controlar stock.
3.7. Gerencia de créditos y seguros / Comité de Créditos: Comité de Gerentes Comerciales
y de Finanzas, encargado del estudio crediticio.
3.8. Gerencia Administración de Ventas: Encargado de desarrollar y controlar el negocio, a
través del Asistente de Ventas y Analista.
4. DOCUMENTOS APLICABLES
N/A
5. TERMINOLOGIA
5.1. FIORI: sistema donde se encuentra el stock, se reservan las unidades y se realizan las
cotizaciones.
5.2. SAV 2000 Legado: Software de Administración de las ventas.
5.3. Acta de Entrega: Formulario que debe ser llenado por vendedor y firmado por el cliente
al momento de entrega de un automóvil al cliente.
5.4. Certificado de Garantía: Formulario establecido por la Fábrica para acreditar la garantía
que tiene el vehículo nuevo que se está vendiendo. La Papeleta de garantía deberá ser
centralizada por la Administración de la Sucursal y remitida al Departamento respectivo
(I-GTIA-07) NOTA: No aplica para vehículos seminuevos.
DOCUMENTO NO CONTROLADO – SOLO USO INTERNO
PROCEDIMIENTO FINANCIAMIENTO
Y VENTA DE AUTOMÓVILES
NUEVOS YSEMINUEVOS
REF: P-VTAS-09 Página 2 de 10
N° Versión: 06
Revisó: Encargado ADV Automóviles
Fecha: 07-11-2022
Aprobó: Gerencia Comercial
Automóviles
Fecha : 17-11-2022
5.5. Certificado de Homologación electrónico: Formulario otorgado por el distribuidor o sus
representantes, estos se deben emitir para cada uno de los vehículos que se
comercializan, mientras el CHI-e se encuentre vigente lo libera de revisión técnica por un
periodo no inferior a 24 ni superior a 36 meses, No aplica para vehículos seminuevos.
5.6. Informe Dicom: Informe para establecer si el cliente o persona que se está consultando,
presenta morosidades, protestos o documentos impagos con algún otro proveedor.
5.7. Seguro de Cambio: Contrato firmado por Kaufmann con un Banco comercial en el que
se compromete a comprar en una fecha futura definida, una cierta cantidad de dólares a
un tipo de cambio definido.
5.8. Carta pro consumidor: informativo de ley pro consumidor
6. EQUIPOS Y HERRAMIENTAS
6.1. Fiori (stock)
6.2. SAV 2000 Legado (ventas)
6.3. Correo Electrónico
6.4. Equifax (Informe Dicom)
6.5. Antecedentes Comerciales
6.6. Informe consolidado (empresa externa)
6.7. SAP
6.8. SII
6.9. Autofact
7. ACTIVIDADES DEL PROCEDIMIENTO
7.1. FORMAS DE FINANCIAMIENTO Y ATRIBUCIONES - CONSIDERACIONES
7.1.1. Retomas y su conversión a dólares.
Las retomas serán valorizadas en pesos. Si la ficha está valorizada en dólares, el auto se retoma
en pesos, pero convertido a dólares con tipo de cambio de la ficha hasta un plazo máximo de 15
días, de lo contrario debe ser revalorizada. Para estos efectos, el valor determinado en el peritaje
tendrá validez de 15 días.
7.1.2. Negocios con “Financiamiento Externo”.
Los negocios con Financiamiento Externo son negocios en dólares (dependiendo de la moneda
en que este ofertado el vehículo), serán valorizados en pesos por la financiera para efectos de
tramitación del crédito internamente. Por lo anterior se respetará el tipo de cambio de cierre de la
operación hasta por un periodo máximo de 3 días. Pasado ese periodo se deberá: a) Solicitar una
nueva carta de curse a la financiera o b) que el cliente asuma las diferencias de cambio entre la
facturación y el pie de la operación. En el caso de existir descuento por parte de la financiera, se
deberá adjuntar el “Mandato de Pago” entre las partes.
Opcionalmente pasar ficha a peso, previa revisión y autorización por Gerencia Automovil
Respetar tipo de cambio de fecha del negocio autorizado por Gerencia Automovil
En ningún caso la Misiva de financiamiento podrá limitar el valor final a facturar cada negocio; por
DOCUMENTO NO CONTROLADO – SOLO USO INTERNO
PROCEDIMIENTO FINANCIAMIENTO
Y VENTA DE AUTOMÓVILES
NUEVOS YSEMINUEVOS
REF: P-VTAS-09 Página 3 de 10
N° Versión: 06
Revisó: Encargado ADV Automóviles
Fecha: 07-11-2022
Aprobó: Gerencia Comercial
Automóviles
Fecha : 17-11-2022
el contrario, solo deberá desglosar el monto de crédito aprobado para el cliente.
La inscripción de los automóviles deberá ser realizada por la Sucursal en un plazo no superior a
3 días hábiles para obtener el certificadoque indique el número de placa patente de la unidad.
Posteriormente deberá ser despachada junto con la factura a la financiera, para que está,
constituya su garantía; considerar que el costode inscripción deberá ser reembolsado por la
entidad antes mencionada.
7.1.3. Negocios con tarjeta de crédito.
Los negocios que sean pagados bajo esta modalidad deberán tener implícito un cobro del 1%,
la que se rebaja del monto pagado que nos paga Transbank, en caso de no realizar este cobro al
cliente deberá estar autorizado expresamente en la ficha por parte de la Gerencia Comercial de
Automóviles que se encuentra autorizado para asumir la comisión. Para efectos de atribuciones
este tipo de ventas son consideradas al contado para el cliente. Se debe tener especial cuidado
con este punto ya que por contrato firmado con Transbank no se pueden traspasar los costos a
los clientes por este tipo de operaciones, por tanto, la única forma de salvar esta situación es
llevar contra descuento el pago de esta comisión, ello implica vender lasunidades a precio lleno
a menos que, como se indicaba antes, esté expresamente autorizado porla Gerencia Comercial.
7.1.4. Pagos contra entrega
Las facturaciones previa a la cancelación del 100% del vehículo deberán estar autorizados por el
Gerente de Sucursal o por el Sub -Gerente Administración y Finanzas y/o similares, estas deberán
ser solicitadas por el vendedor única y exclusivamente para los clientes antiguos (que hayan
comprado a lo menos 1 automóvil anteriormente) y/o conocidos de la Gerencia de Sucursalo
Comercial, ello deberá estar expresado en la ficha de ventas mediante comentario. Esto será
corroborado por quien autoriza consultando las fichas de ventas históricas del cliente, de lo
contrario será responsabilidad de quien autoriza un eventual problema en los pagos de la unidad.
Lo anterior en caso de tratarse de una cancelación al contado, ya que de tratarse de una
operación al crédito, aplican las actividades del procedimiento para este tipo de negocios. La
recepción de los valores se efectuará al tipo de cambio de la fecha de esta recepción y no al tipo
de cambio de la factura.
7.1.5. Atribución y sus niveles
En la siguiente tabla se resumen las atribuciones de crédito y sus requisitos
DOCUMENTO NO CONTROLADO – SOLO USO INTERNO
PROCEDIMIENTO FINANCIAMIENTO
Y VENTA DE AUTOMÓVILES
NUEVOS YSEMINUEVOS
REF: P-VTAS-09 Página 4 de 10
N° Versión: 06
Revisó: Encargado ADV Automóviles
Fecha: 07-11-2022
Aprobó: Gerencia Comercial
Automóviles
Fecha : 17-11-2022
El “Product Manager de Automóviles” reemplazara al Gerente Comercial para el punto
“ATRIBUCIONES Y SUS NIVELES” en caso de ausencia de este último. En el evento que nadie
esté disponible será el “Comité de Crédito” o el Gerente General si fuese necesario.
7.1.6. Consignación pactada
En el caso que un cliente cancele, con un vehículo en parte de pago en estado de "Consignación"
(PACTADA), aplicara el mismo proceder y revisión de las retomas; se debe adjuntar CAV,
Certificado de multas, Informe consolidado, más copia del "Contrato Consignación con promesa
de venta a KSAVM", donde se obliga al cliente a vendernos irrevocablemente el automóvil
"CONSIGNADO", una vez vencido el plazo. Paralelamente a este contrato se deberá dejar
firmado el CONTRATO DE COMPRAVENTA abierto al nuevo comprador.
7.1.7. Venta Automóviles seminuevos
Todos los negocios por venta de automóviles seminuevos se rigen bajo los mismos
procedimientos y consideraciones antes descritos.
7.1.8. Venta clientes interno
Este tipo de negocio deberá ser canalizado en cada sucursal y con el vendedor asignado para
ello, el lineamiento a utilizar será el “INSTRUCTIVO CONDICIONES COMPRA AUTOS MB PARA
COLABORADORES KAUFMANN”, distribuido por la Gerencia de Administración de Ventas y
visado por la GAFI.
7.1.9. Gastos operaciones y cortesía
Los gastos operaciones en la venta de vehículos deberán ser cargados a cada cliente en un plazo
mínimo de rendición. El comprador deberá cancelar los gastos anticipadamente o en su defecto
“contra entrega”. Cualquier excepción deberá ser autorizada por el Gerente de la Sucursal y/o
similares, ya que afectara el margen y comisión del negocio.
En cualquier caso (gastos-cortesía) deberán ser incorporados en la cotización en Fiori como
intangibles.
7.2. ACTIVIDADES.
7.2.1. Gerente Comercial Automóviles
Establecer Políticas Comerciales y según atribuciones autorizar las formas de pago al crédito
cuando estas sean iguales o menores a 4 meses, considerando un mínimo de 30% de pie.
7.2.2. Gerente de Sucursal
Establecer un control a los precios de venta, velar por el nivel de descuentos y volumen de
negocios en cuanto a las metas establecidas por el presupuesto anual. Además de autorizar las
salidas de los automóviles vendidos al crédito por la sucursal.
DOCUMENTO NO CONTROLADO – SOLO USO INTERNO
PROCEDIMIENTO FINANCIAMIENTO
Y VENTA DE AUTOMÓVILES
NUEVOS YSEMINUEVOS
REF: P-VTAS-09 Página 5 de 10
N° Versión: 06
Revisó: Encargado ADV Automóviles
Fecha: 07-11-2022
Aprobó: Gerencia Comercial
Automóviles
Fecha : 17-11-2022
“LA ENTREGA FISICA DE LA UNIDAD SERA RESPONSABILIDAD DEL
GERENTE Y SUBGERENTE DE ADM Y FINANZAS O SIMILAR DE LA
SUCURSAL”
7.2.3. Sub Gerente Administración y Finanzas/ Jefe de Administración/ Encargados
Administrativos.
Encargado de velar por el cumplimiento del presente procedimiento, reemplazar al Gerente de
Sucursal para autorizar las salidas de los automóviles vendidos al crédito.
En caso que el automóvil sea pagado con cheque al día no cobrado, la salida deberá ser
expresamente autorizada mediante CONTRASEÑA visada y/o comentario en la ficha SAV Legado por
el Gerente de Sucursal, en su ausencia el Sub-Gerente de Administración y Finanzaso similar en la
Sucursal.
“LA ENTREGA FISICA DE LA UNIDAD SERA RESPONSABILIDAD DEL
GERENTE Y SUBGERENTE DE ADM Y FINANZAS O SIMILAR DE LA
SUCURSAL”
7.2.4. Vendedor de Automóviles
Encargado de ofrecer los automóviles disponibles para la venta o bien una venta a futuro, de acuerdo
a la política de precios dictada por la Gerencia Comercial en coordinación con la Gerencia de Sucursal,
considerando el procedimiento en cuestión según la forma de pago negociada con el cliente.
7.2.4.1. Cada vendedor deberá consultar la disponibilidad de stock en Fiori.
7.2.4.2. Una vez revisado el stock podrá realizar la cotización formal al cliente.
7.2.4.3. Si se concreta la venta el vendedor deberá reservar la unidad en Fiori y si es
necesario actualizar los valores de la cotización.
7.2.4.4. Con la cotización deberá ir al Legados menú oferta e ingresar el número de la
cotización para que el sistema del número de oferta.
7.2.4.5. Si el negocio está concretado (con abonos o acuerdos formales con cliente), desde
la oferta se procede a confeccionar la ficha de ventas, dejándola vigenteprevia
confirmación de descuento, financiamiento, garantías comerciales, Dicom, tipo de
cliente, y utilización de Macros Estándar para calcular la fecha comprometida de
entrega.
7.2.4.6.
Si existen abonos de dinero, es condicionante sin excepción alguna, que esté
confeccionada la ficha de ventas, el cajero deberá registrar cada abono de dinero,
registrando en la glosa de cada ingreso cuál es el número de ficha involucrado, en
caso de pagos via Web pay cargar comprobante o detalle de cuenta.
7.2.4.7. Para las condiciones de cierre del negocio al crédito, el vendedor de automóviles
deberá solicitar al cliente los siguientes antecedentes:
DOCUMENTO NO CONTROLADO – SOLO USO INTERNO
PROCEDIMIENTO FINANCIAMIENTO
Y VENTA DE AUTOMÓVILES
NUEVOS YSEMINUEVOS
REF: P-VTAS-09 Página 6 de 10
N° Versión: 06
Revisó: Encargado ADV Automóviles
Fecha: 07-11-2022
Aprobó: Gerencia Comercial
Automóviles
Fecha : 17-11-2022
a) Carnet de identidad
b) Nro. de cuenta corriente y banco de los cheques que entregara para el
Pago del automóvil
c) Certificado de soltería en caso de ser mujer soltera
d) Certificado de matrimonio en el caso de ser mujer casada
e) Certificado actualizado DICOM
CRÉDITOS PAGADEROS CON CHEQUES, LETRAS DE CAMBIO,
RECONOCIMIENTO DE DEUDA O LEASING FINANCIERO
a) Carnet de identidad
b) Nro. de cuenta corriente y banco de los cheques recibidos para el pagodel
automóvil
c) Certificado de soltería de mujer soltera
d) Certificado de matrimonio de mujer casada
e) Antecedentes financieros: acreditación de renta mediante IVAS para las
empresas, liquidaciones de sueldo para empleados, Boletas deHonorarios
para prestadores de servicios, informe ejecutivo que describaal cliente.
f) Antecedentes Legales para las empresas: Constitución de Sociedad,
Certificado de Vigencia, Publicación en el diario Oficial, Copia rut y
representante. Para S.A. se deberá incluir sesión o acta donde se designeel
Gerente General y sus atribuciones.
g) Para persona natural, mujer, soltera: certificado de soltería y certificado de
matrimonio en el caso de mujer casada.
7.2.4.8. Para créditos (ver 7.1.5) “Atribución y sus niveles”, en cualquier forma elasistente
administrativo de automóviles nuevos, deberá enviar los antecedentesal Comité de
Créditos para su V°B° y solicitar al vendedor antecedentes del cliente que dicho
Comité requiera.
7.2.4.9. Después que el vendedor de automóviles ha cerrado el negocio con el cliente, ylas
condiciones de pago han sido establecidas como contado, ejemplo cheque al día,
Efectivo, Vale Vista, Tarjeta de Crédito, Financiamientos externos, Leasing Externos,
Financieras. El vendedor de automóviles deberá solicitar un Informe de Dicom del
cliente. Conjuntamente, el vendedor deberá obtener fotocopia del carnet para validar
los datos del cliente y evitar rechazos al momento de su inscripción.
DOCUMENTO IMPRESO NO CONTROLADO – SOLO USO INTERNO
PROCEDIMIENTO FINANCIAMIENTO
Y VENTA DE AUTOMÓVILES
NUEVOS YSEMINUEVOS
REF: P-VTAS-09 Página 7 de 10
N° Versión: 06
Revisó: Encargado ADV Automóviles
Fecha: 07-11-2022
Aprobó: Gerencia Comercial
Automóviles
Fecha : 17-11-2022
7.2.4.10. Si el cliente consultado tiene anotaciones negativas menores en el Dicom, la
venta deberá pasar a una instancia de análisis entre el Gerente de sucursal y el
Sub- Gerente de la Sucursal. Son anotaciones menores las multas de tránsito,
tag o similares. Las anotaciones negativas de mayor envergadura deberán
consultarse al Depto. de Análisis de Riesgo. Sin embargo, si la operación es al
contado, bastará la conformidad de los fondos para entregar el auto.
7.2.4.11. Si el resultado del informe de Dicom no registra anotaciones negativas, el
vendedor de automóviles deberá hacer ingreso de los documentos de pago de
la unidad nueva a la caja, quien registrará de forma inmediata el ingreso al
sistema de caja diaria.
7.2.4.12. Paralelamente al punto anterior el vendedor de automóviles deberá confeccionar
en el sistema SAV Legado la ficha de ventas, bajo la condición de negocio
CONTADO o CREDITO para ese automóvil, deberá reservar el pedido
cerciorándose de que no se encuentre ofertado por otro vendedor, indicando en
la ficha de ventas la real forma del pago del vehículo.
7.2.4.13. El vendedor luego de contar con la certificación que los contratos se encuentran
firmados y todos los demás documentos en reglas deberá coordinar la visación
y/o contraseña de salida con el Gerente de Sucursal o en su ausencia con el
Sub Gerente o similares; Con esto último aprobado podrá realizar la entrega
física de automóvil, además, de obtener la firma por parte del cliente del cedible
de la factura, acta de entrega y certificado de garantía, para posteriormente ser
enviado inmediatamente al asistente administrativo de ventas para ser cargado
en la ficha de ventas.
“LA ENTREGA FISICA DE LA UNIDAD SERA RESPONSABILIDAD DEL
GERENTE Y SUBGERENTE DE ADM Y FINANZAS O SIMILAR DE LA
SUCURSAL”
7.2.4.14. Una vez entregado el automóvil, el vendedor deberá hacer devolución inmediata
al Asistente Administrativo de Ventas, el certificado de garantía y actade entrega,
contratos firmados por el cliente etc., además cargar en la Fv la documentación.
7.2.5. Asistente Administrativo de Ventas.
Encargado recolección y confección de la carpeta de venta, considerando para ello todos los
documentos que respalden la operación de venta. Realiza seguimiento hasta que se finiquite la
ficha de venta.
7.2.5.1. Después de la confección de la ficha de venta, el vendedor y/o asistente de
ventas, deberá conseguir todos los vistos buenos, realizar la pre-visualización
de la factura y pedir la facturación a través del pedido”.
DOCUMENTO IMPRESO NO CONTROLADO – SOLO USO INTERNO
PROCEDIMIENTO FINANCIAMIENTO
Y VENTA DE AUTOMÓVILES
NUEVOS YSEMINUEVOS
REF: P-VTAS-09 Página 8 de 10
N° Versión: 06
Revisó: Encargado ADV Automóviles
Fecha: 07-11-2022
Aprobó: Gerencia Comercial
Automóviles
Fecha : 17-11-2022
7.2.5.2. El Asistente Administrativo de ventas, con todos los antecedentes
proporcionados por el vendedor, deberá confirmar previamente lo siguiente:
a) Cliente se encuentra bien creado en el sistema, nombres, dirección, giro etc.
b) Forma de pago registrada en la ficha de ventas sea fidedigna respecto
De la registrada en los recibos de dinero.
7.2.5.3. Paralelamente al punto anterior el Asistente Administrativo de Ventas deberá
cargar todos los antecedentes relativos al negocio en la ficha, como son recibos
de dinero, carta Forum/BK (financiamiento externos), C.I. del comprador, C.I.
compra para, orden de compra, rut en el caso de ser persona jurídica, CAV,
Informe de deuda consolidada del seminuevos (EMPRESA EXTERNA),
certificado de multas si es una retoma; en el caso de que compre la empresa es
necesario carta de traspaso, carta abono pie, pago de impuesto Municipal (sólo
para venta de Automóviles seminuevos), Se deja constancia que la venta de
automóviles seminuevos lleva implícito el pago por parte del cliente del impuesto
de transferencia respectivo. En el caso de que llegase a faltar algún
antecedente, será comunicado vía SAV Legado al vendedor y/o Asistente
Administrativo de Ventas mediante evento en Ficha.
7.2.5.4. En todos los casos de crédito, el asistente administrativo de automóviles cargara
cada documento con su nombre y glosa respectiva en la ficha, antes de solicitar
la facturación de la unidad, cerciorándose de que se cuente con todos los
antecedentes para la confección de los contratos y la facturación de la venta.
Además, que las condiciones de la ficha correspondan a la realidad de recibos
y demás condiciones de crédito.
7.2.5.5. Para el caso de los créditos (letras) el Asistente Administrativo de ventas (de la
sucursal) deberá coordinar la impresión de las mismas y la toma de firma de
ambas partes en notaria.
7.2.5.6. El Asistente Administrativo, con todos los antecedentes proporcionados por el
vendedor, deberá solicitar al departamento de Administración de Ventas la
facturación de la unidad, además de la confección de la escritura respectiva (si
procede). Considerar que la “Escritura Pública” debe ser firmada en notaria o
solicitar visita del Notario a la Sucursal con cargo a cliente.
7.2.5.7. Una vez recibida la factura, contratos y/o letras (según sea el caso), el Asistente
Administrativo de Ventas coordinará la firma del cliente en la notaria ANTES DE
LA ENTREGA DE LA UNIDAD para el caso de los negocios con prenda. La
inscripción de los automóviles deberá ser realizada por la Sucursal para obtener
el certificado que indique el número de placa patente de la unidad, con el fin de
constituir la garantía.
7.2.5.8. El Asistente Administrativo de ventas procederá al archivo de la carpeta del
negocio (sucursal), con la certeza de que fueron cargados a Sav 2000 Legado
DOCUMENTO IMPRESO NO CONTROLADO – SOLO USO INTERNO
PROCEDIMIENTO FINANCIAMIENTO
Y VENTA DE AUTOMÓVILES
NUEVOS YSEMINUEVOS
REF: P-VTAS-09 Página 9 de 10
N° Versión: 06
Revisó: Encargado ADV Automóviles
Fecha: 07-11-2022
Aprobó: Gerencia Comercial
Automóviles
Fecha : 17-11-2022
TODOS los antecedentes.
7.2.5.9. El Asistente Administrativo de ventas deberá cargar en la FV la solicitud de
primera inscripción y solicitar al ejecutivo de cuentas mediante evento en la FV
la emisión del certificado de homologación electrónico.
7.2.5.10. El Asistente Administrativo de ventas carga todos los antecedentes a en la FV.
En el caso de los negocios constitutivos de prenda, se deberá informar el término
el trámite, y esta garantía se deberá validar con un certificado de notaciones
vigentes (CAV).
7.2.6. Encargado Stock de Automóviles Nuevos/Seminuevos
Planifica y controla stock de automóviles, coordinando y reportando anomalías a Logística,
además, gestionará la salida del vehículo en el sistema el mismo día de la entrega real.
7.2.7. Gerencia de créditos y seguros/Comité de Créditos
Comité de Gerentes Comercial y Finanzas, encargados de autorizar, rechazar o realizar alcances
para los créditos solicitados por la sucursal para financiar venta de automóviles al crédito.
7.2.8. Gerencia Administración de Ventas
Es el encargado de controlar, facturar y velar por el cumplimiento de este procedimiento, hasta el
finiquito de la operación, aprobando y desarrollando sólo los negocios que cumplan con los
requisitos mínimos exigidos.
7.2.8.1. Ejecutivo de Cuentas procederá a revisar y cotejar el negocio. Transfiere la venta
(en el caso de seminuevos) y/o emite la factura de ventas, adicionando a éste
certificado de Homologación y garantía, más cortesías (cuando proceda). Se
prepara un Memorándum y se despacha a sucursal.
7.2.8.2. El Analista ADV controla el negocio, realizando el seguimiento hasta el finiquito
de la operación.
8. REGISTROS.
8.1. Ficha de Ventas
8.2. Recibos de Pago
8.3. Orden de compra
DOCUMENTO IMPRESO NO CONTROLADO – SOLO USO INTERNO
PROCEDIMIENTO FINANCIAMIENTO
Y VENTA DE AUTOMÓVILES
NUEVOS YSEMINUEVOS
REF: P-VTAS-09 Página 10 de 10
N° Versión: 06
Revisó: Encargado ADV Automóviles
Fecha: 07-11-2022
Aprobó: Gerencia Comercial
Automóviles
Fecha : 17-11-2022
8.4. Carta de curse crédito (financiamiento externo)
8.5. Copia factura
8.6. homologado electrónico.
8.7. Contrato de prenda
8.8. Contrato de reconocimiento de deuda
8.9. Contrato de arriendo Leasing Financiero
8.10. Eventos
8.11. Garantía aceptada
8.12. Actas de entrega
8.13. Liquidación contable
8.14. Cartas pro- consumidor
8.15. Cartas traspasos fondo
8.16. Cartas autorización compra para
9. ANEXOS.
10. MODIFICACIONES DEL DOCUMENTO
Se cambia referencia, viene de P-ZMOA-04 a P-VTAS-09