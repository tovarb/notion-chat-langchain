# PROTOCOLO ATENCIÓN VEHÍCULOS COMERCIALES PESADOS

1. Objetivo
Brindar una atención de calidad a los clientes y prospectos. Dando cumplimiento a la misión
y visión de la empresa.
2. Alcance
Esta actividad se desarrolla en las sucursales, hasta la contabilización en las cuentas de
proveedores imputando gastos, notas de crédito, y/o abonos.
3. Responsabilidad
3.1. Vendedor vehículos comerciales pesados: Dar cumplimiento a este protocolo, para
lograr multiplicar los contactos de clientes y prospectos.
4. Documentos aplicables.
4.1. Cotización Kaufmann estandarizada con modelo/s de vehículo/s solicitado/s y
equipamiento.
4.2. Ficha técnica del producto/s cotizado/s.
4.3. Díptico de Kaufmann Servicios Financieros (acompañado de protocolo KSF).
4.4. Díptico informativo de contratos de mantenimiento.
4.5. Catalogo genérico del modelo de interés del cliente. (En caso de conocer su
necesidad).
5. Equipos y Herramientas
5.1. PC.
5.2. E-Mail.
5.3. Impresora.
5.4. Internet
5.5. Appstore Kaufmann.
5.6. Portal CRM
6. Actividades del protocolo
6.1. Prospección:
Es una rutina de trabajo que permite multiplicar tus contactos con clientes y prospectos,
tomando así la iniciativa de los procesos comerciales.
La llamada telefónica
El objetivo de la llamada es lograr una entrevista personal en las instalaciones del cliente o
que el cliente te visite en la sucursal.
Realiza llamadas profesionales que transmitan una buena imagen de Kaufmann al cliente.
6.1.1. Protocolo de llamada:
Buenos días/tardes:
Mi nombre es XXXXX XXXXXX, asesor de ventas en Kaufmann.
¿Podría comunicarme con el Sr/Sra XXXXXX XXXXXX?
“El motivo de mi llamado se debe a:
-Que usted podría estar interesado en la compra de XXXX (modelo determinado vehículo)
-Presentarle nuestra gama de vehículos
-Dar a conocer nuestro modelo XXX que podría ser útil para el desempeño de su negocio
-Ofrecerle un vehículo con alternativas de financiamiento
-En estos momentos tenemos una oferta interesante de …..
¿Le parece si nos reunimos para darle más detalles y mostrarle las distintas alternativas
que tenemos disponibles?
Ante una respuesta positiva del cliente (cliente muestra interés):
Don XXXX ¿Tiene disponibilidad para reunirse dentro de los próximos días? ¿Le parece el
día XXXX?
¿Puede venir a una de nuestras sucursales o prefiere que lo visite en su lugar de trabajo?
Una vez definida la cita, confirmar datos:
Bien Don XXXX, dejamos agendada nuestra cita para el día (dd/mm) a las HH:MM hrs en
calle, número, comuna.
Le enviaré un correo recordándole nuestra cita el día previo a la fecha acordada. Me figura
que su correo electónico es [XXXXX@XXXXX.CL](mailto:XXXXX@XXXXX.CL) , está correcto? (actualizar información en
CRM)
Le agradezco su tiempo, nos vemos en la fecha acordada, hasta luego.

6.2. Recepción del cliente:
Se trata del primer contacto que tiene el cliente con nuestra empresa, provocará una
impresión inicial de lo que será su experiencia de atención en Kaufmann y del equipo
profesional que trabaja en ella. Debes hacer de la acogida el primer paso del acto de venta.
En esta fase son determinantes las impresiones sensoriales, ante todo, las visuales.
Procura que tu presentación personal, uniforme, puesto de trabajo y material a entregar a
clientes, cumplan con el estándar de imagen corporativa.
Presentación personal:

- Recuerda estar afeitado, peinado y con tu uniforme corporativo limpio y completo,
zapatos lustrados, piocha con tu nombre.
Recepción del vendedor:
- Demuestra profesionalismo con una buena acogida, transmitiendo confianza al cliente,
sin hacer discriminaciones ni prejuicios.
- Dirígete al cliente con una sonrisa
- Saluda dando la mano firmemente manteniendo contacto visual y preséntate con tu
Nombre, apellido y cargo.
6.2.1. Protocolo de recepción del vendedor
V: Buenos días/tardes don XXXXXXX mi nombre es NOMBRE APELLIDO, asesor de
ventas de vehículos comerciales. ¿En qué puedo ayudarle?
C: Si el cliente expresa su deseo de “mirar”, “dar un vistazo” a los vehículos en exhibición
V: Don XXXXX, mire con tranquilidad, estoy a su disposición en caso de que necesite
información.
C: Si el cliente solicita información de algún vehículo.
V: Lo acompaño para mostrarle el vehículo en nuestro showroom.
Una vez que el cliente haya mirado los vehículos en exhibición debes acudir a tu puesto de
trabajo junto con el cliente y conversar sobre sus intereses y necesidades. Comenzar la
fase de evaluación de las necesidades del cliente para ofrecerle el vehículo más adecuado.
V: Don XXXX le solicitaré algunos datos para generar una cotización del modelo de
su interés

6.3. Preparación de entrevista con el cliente.
La entrevista se producirá a partir de tus actividades de prospección y de seguimiento de
tu cartera de clientes. En algunos casos podrá tener lugar en las instalaciones del cliente y
otras será él quien acuda a nuestras sucursales para ver nuestros vehículos y soporte de
taller.
Siempre es necesario dedicar tiempo suficiente para prepararnos, pues una entrevista
comercial mal preparada será seguramente una pérdida de tiempo, tanto para el vendedor
como para el cliente.
¿Cómo informarte sobre el cliente/prospecto?
Apóyate en CRM para obtener información histórica de quien vas a visitar.
Obtén una visión 360 del cliente (Revisa cupo del crédito, cuenta corriente, garantía,
productos que tiene y vehículos que se encuentren en taller)
Visita la web de la empresa del cliente para complementar tu información.
Recopila los datos que te permitan orientar tu asesoría hacia lo que el cliente necesita.
Demuestra al cliente que conoces su negocio.
Detecta las lagunas en tu información que deberás completar tras la visita y ampliar tu
conocimiento del cliente.
Define un objetivo para esa entrevista:

- Darte a conocer: presentar la empresa y la oferta integral de Kaufmann
- Detectar necesidades a mediano/largo plazo del cliente
- Valorar su predisposición a comprar
- Lograr un contacto posterior con los decisores/usuarios de compra.
- Lograr que el cliente visite la sucursal
- Lograr que el cliente realice una prueba del vehículo
- Enviar información de producto de su interés.
- Generar un nuevo contacto
- Obtener referidos
- Prepara preguntas abiertas y de calidad orientadas al objetivo de la visita y que nos
den información (“que hagan hablar al cliente”).
- Anticipa las objeciones que el cliente pueda tener a nuestras distintas propuestas
- Prepara respuestas de calidad a las objeciones más frecuentes (revisa el listado de
objeciones y respuestas presente en tu cuaderno de visitas)
Medios de apoyo a utilizar para entregar al cliente y reforzar tu visita:
- Catálogo genérico del modelo de interés del cliente (en caso de conocer su
necesidad)
- Ficha técnica de modelo de interés del cliente (en caso de conocer su necesidad)

Material corporativo para uso del vendedor:

- Cuaderno corporativo con formulario de detección de necesidades (para pautear la
entrevista)
- Tarjetas de presentación corporativas.
6.4. Entrevista inicial:
La entrevista inicial es una instancia para comprender las necesidades de nuestro cliente.
Es fundamental escuchar atentamente sin interrumpir para luego poder asesorarle de la
mejor manera.
Si nuestra argumentación se ajusta a lo que el cliente necesita, nuestras posibilidades de
éxito serán mucho mayores, por lo que la detección de necesidades es fundamental.
Recuerda que los clientes Premium esperan vendedores Premium: lo primero que te
vendes eres tú.
- Confirma siempre la visita con uno o dos días de antelación: lugar, fecha, hora,
duración.
- En el momento de la visita se puntual siempre
- Crea clima: recurrir a temas generales o relacionados con el cliente que visitas.
- Recuerda brevemente al cliente los términos más importantes tratados en contactos
anteriores
- Escucha atentamente al cliente poniendo atención a todo aquello que te quiera
transmitir (escucha activa).
- Toma nota de todo lo que sea relevante para etapas posteriores del proceso
comercial
- Si el cliente pide una oferta, aclárale que necesitas tener más conocimiento de su
situación y sus necesidades para hacer una oferta ajustada
- Lleva la iniciativa y recuerda adaptar tu lenguaje y comunicación al de tu interlocutor
- Comenta al cliente que requieres hacerle algunas preguntas que te den más
información sobre sus necesidades y lograr así ofrecerle el vehículo que se ajuste a
sus necesidades.
- Formula las “Preguntas de Detección de Necesidades” (seguir protocolo de
atención)
- Comenta al cliente la existencia de Contrato de Mantenimiento, hazle entrega del
díptico informativo y formula las preguntas del cuestionario de contratos de
mantenimiento presentes en tu cuaderno de visitas. (seguir protocolo de atención)
- Resume la entrevista con el cliente, confirma sus necesidades, preferencias y
argumentos decisivos

- Define compromisos establecidos con el cliente y fecha de envío de información
acordada
- Ofrecer una prueba de conducción.
- Coordinar con el cliente una visita a alguna sucursal Kaufmann para presentarle el
vehículo
- Solicita entrevistas con otros decisores de compra o usuarios (si es necesario)
- Despídete del cliente recalcando los compromisos acordados (seguir protocolo de
despedida)
6.4.1. Protocolo para formulación de preguntas de detección de necesidades.
“Permítame realizarle algunas preguntas sobre su necesidad de transporte para
poder asesorarle adecuadamente”. (Guíate en las preguntas del formulario en tu
cuaderno y completa con la información entregada por el cliente).
6.4.2. Protocolo para ofrecer contratos de mantenimiento.
Don XXX, le comento que en Kaufmann contamos con la alternativa de Contratos de
Mantenimiento, se trata de un programa que contempla las mantenciones en su
vehículo a valores preferenciales lo que se refleja en menores costos de servicio.
Cuenta también con la opción de incluir este monto en el financiamiento de su
vehículo.
¿Tiene interés en que le coticemos este servicio?
Le haré algunas preguntas para poder entregarle una propuesta adaptada a su
negocio
Formula las preguntas del cuestionario de contratos de mantenimiento incluido en tu
cuaderno y registra las respuestas.
“Le hago entrega de un díptico informativo de contratos de mantenimiento. Para que
pueda revisar en detalle las alternativas que tenemos”
Toma contacto con la persona responsable de contratos de mantenimiento en tu zona o
bien en casa Matriz.
6.4.3. Protocolo para dar a conocer la APP Kaufmann
“Le comento que Kaufmann cuenta con una aplicación donde mantenemos
informados a nuestros clientes sobre novedades, el estado de sus vehículos en taller,
ofertas disponibles, entre otros temas que facilitarán su comunicación con nosotros,
puede descargarla de appstore directamente sin costo”

6.4.4. Protocolo de Despedida.
“Don XXXX muchas gracias por su tiempo, le agradezco su interés, según lo
comprometido, el día XX/XX le enviaré a su correo la información acordada (Confirmar
correo y teléfono del cliente).
Hasta luego y que tenga un buen día” (Despedirse de pie, dando la mano firmemente
acompañado de contacto visual y una sonrisa)

- Una vez de regreso en la sucursal, registra en CRM el contacto, solicitudes y
compromisos adquiridos con el cliente.
6.5. Presentación del vehículo:
La presentación del vehículo es una oportunidad de impresionar al cliente, generará un
impacto directo en la experiencia de compra de nuestros clientes.
En este momento le transmitirás entusiasmo por la marca, certeza en las características
superiores de nuestro producto frente a la competencia (en calidad, seguridad, innovación
y servicio postventa) y confianza en el respaldo de nuestra empresa mediante el
profesionalismo de nuestro equipo comercial.
- Comprueba que el vehículo a presentar se encuentre disponible, limpio y en
perfectas condiciones.
- Repasa las características del vehículo (equipamiento, opciones, aspectos técnicos,
etc).
- Potencia los aspectos de valor para el cliente que coincidan con sus criterios de
decisión.
- Repasa el comparativo de los modelos de la competencia y destaca las fortalezas
del vehículo que estas presentando (revisa cuadros comparativos con la
competencia). Ingresando al portal Km 0 podrás revisar información comparativa de
los principales modelos de Kaufmann y de la competencia.
- Aclara las diferencias entre los distintos modelos, variantes y posibles
equipamientos.
- Entrega Información de la Marca y fiabilidad del modelo
- Sigue el proceso de presentación ordenado e integral “walk around”
- Ayuda a decidir al cliente entre modelos, opciones, equipamientos
- Resume las ventajas y beneficios principales del vehículo respecto a diseño,
seguridad, rendimiento, etc.
- Ingresa en CRM el registro de la presentación del vehículo.

6.6. Prueba de Conducción (Test Dive)
La prueba de conducción es un momento decisivo en el proceso de compra del cliente. Es,
en muchos casos, la experiencia que hace que el cliente tome la decisión de compra, pues
el convencimiento personal es el mejor argumento en la comparación con otras opciones
de la competencia. Existe, por otra parte, una relación directa entre la prueba en ruta y
ventas. La disposición a comprar aumenta cuando el cliente tiene posibilidad de hacer la
prueba o disponer del vehículo para probarlo, debes lograr que el cliente se “encante” con
el vehículo;

- Pregunta al cliente por su interés en realizar una prueba en ruta
- Consulta disponibilidad de vehículos Demo y coordina el préstamo con los product
managers.
- Acuerda con el cliente fecha y hora para la prueba.
- Cerciórate de que el demo se encuentre en condiciones de préstamo (verificar carga
de combustible, estado exterior e interior, limpieza del vehículo etc)
- Planifica ruta de prueba en función de cliente y el uso del vehículo
- Procura contar con la presencia de un instructor técnico o del Ingeniero a cargo
como apoyo en la prueba del vehículo (la presencia del instructor dependerá de su
disponibilidad)
- Demuestra el desempeño del vehículo y el uso de sus prestaciones, destacando sus
ventajas y beneficios a través de su experiencia directa.
- Tu asesoría en la conducción del vehículo es fundamental para que el cliente saque
el máximo provecho al consumo del vehículo (apóyate en Fleetboard para MB)
- Propón el siguiente paso al cliente: Presentar la oferta.
- Una vez finalizada la prueba, genera la actividad de contacto en CRM.
6.7. Propuesta comercial.
La oferta personalizada (denominada cotización en CRM), incluye todos los productos y
servicios de valor para el cliente, (cotización del vehículo, venta cruzada, equipamientos,
servicio post venta, financiamiento etc) con que podemos acompañar la operación de venta
del vehículo.
En aquellos casos en los que sea necesaria la retoma de vehículos, se llevará a cabo el
proceso de peritaje y tasación de un vehículo usado que se realizará en paralelo a la
confección de la oferta comercial.
- Entrega la cotización al cliente y explica detalladamente cada uno de los productos
y servicios ofrecidos.
- Ofrece al cliente la opción de contar con alternativas de financiamiento (KSF)
entrega el díptico informativo (acompañado del protocolo establecido).
- Explica las ventajas de las distintas opciones sugeridas
- Ofrece al cliente el peritaje y retoma de su vehículo
- Aclara todas las posibles dudas
- Pregunta al cliente su opinión
- De acuerdo a la validez de la oferta (15 días), debes indicar al cliente que en un
plazo de 10 días lo contactarás para conocer su decisión y avanzar en el proceso
de compra del vehículo (llamada acorde a protocolo de seguimiento).
- Si el cliente manifiesta interés a largo plazo, debes actualizar la oportunidad en CRM
acorde a las fechas entregadas por el cliente (3 a 6 meses).
En carpeta corporativa entregar al cliente los siguientes documentos:
- Cotización Kaufmann estandarizada con modelo/s de vehículo/s solicitado/s y
equipamiento
- Ficha técnica del producto/s cotizado/s
- Ficha técnica de equipos especiales
- Díptico de Kaufmann Servicios Financieros (acompañado de protocolo KSF)
6.7.1. Protocolo de ofrecimiento de alternativas de Financiamiento (KSF)
“Kaufmann pone a su disposición financiamiento para su inversión a través de nuestro brazo
financiero Kaufmann Servicios Financieros (KSF) ya sea a través de un crédito y/o un
leasing a tasas competitivas.
Le hago entrega de un folleto donde encontrará detalles de los servicios que tenemos para
usted” (entrega díptico KSF)
¿Tiene usted interés en optar por alguna alternativa de financiamiento? Kaufmann Servicios
Financieros, cuenta con ejecutivos a lo largo de todo Chile. ¿Lo contacto con nuestro
ejecutivo? (si el cliente accede, contactar posteriormente con ejecutivo KSF)
6.7.2. Protocolo de seguimiento de la oferta comercial (acorde a interés en el corto
plazo).
Vendedor y cliente revisarán detenidamente la oferta comercial, debes explicar
detalladamente cada punto presente en la cotización.
“Don XXXX, dentro de 10 días lo contactaré para conocer su opinión y decisión sobre la
compra del vehículo, cualquier inquietud que tenga en el transcurso de ese tiempo, estaré
disponible para asesorarle y resolver sus dudas”
6.7.3. Protocolo de despedida.
¿Hay algo más en que le pueda ayudar?
Si el cliente no tiene comentarios adicionales,

“Hasta luego don XXXX, estaremos en contacto, que tenga un buen día” (Despedirse
de pie, dando la mano firmemente, acompañado de contacto visual y una sonrisa)
6.8. Negociación y cierre de la venta.
El cierre puede producirse en la misma entrevista en la que hayas presentado la propuesta
o bien dilatarse a lo largo de distintas entrevistas en las que se produzca un proceso de
negociación. En ese caso, deberás reelaborar la Propuesta Comercial hasta que refleje el
acuerdo alcanzado y presentarla en varias ocasiones.
Pasar de la oferta a la firma requiere profesionalismo y estilo. Aunque la oferta no prospere,
siempre será un punto de partida para posibles contactos posteriores.
Previo a reunirte con el cliente

- Repasa las condiciones de la oferta
- Repasa la información cualitativa del cliente: preferencias, objeciones planteadas, etc.
- Anticipa posibles objeciones y respuestas
- Prepara la negociación y argumentos a reforzar
- Desarrollar argumentos para apoyar el cierre de la venta: producto, servicio, Marca.
- Prepara la documentación necesaria
- Consulta internamente las fechas y plazos de entrega estimados para los vehículos.
En presencia del cliente
- Repasa con el cliente la propuesta de venta:
- Modelo y equipamiento
- Financiamiento (si aplica)
- Contrato de mantenimiento
- Condiciones de retoma si se entrega vehículo a cambio.
- Define las variables a negociar (financiamiento, equipamiento, mantenimientos, etc)
- Manifiesta la predisposición al beneficio mutuo y a facilitar el desarrollo de la
negociación
- No negocies aspectos que el cliente no perciba como un esfuerzo de tu parte: no se
valora lo que no cuesta.
- Argumenta la relación valor-precio.
- Despeja dudas y resistencias para cerrar la operación El cliente puede tener dudas u
objeciones sobre algún aspecto concreto o puede plantear una negociación de la oferta
para obtener mejores condiciones.
- Comprende al cliente, no te pongas a la defensiva ante una objeción. Recuerda que el
cliente siempre tiene derecho a tener dudas o reservas
- Aborda el tratamiento de objeciones con profesionalismo: da al cliente información
adicional y propón alternativas,
- Confirmar que el cliente está satisfecho con la respuesta recibida
- Se transparente y entregar toda la información para no generar problemas o
confusiones a futuro. Transparenta plazos de pago, confirmación de fondos y trámites
internos.
- Acuerda la fecha estimada de entrega
- Indica plazos estimados de entrega (acorde a la configuración del vehículo y
disponibilidad), comprométete a dar una fecha final una vez cerrado el negocio.
- Deja todos los compromisos por escrito con el fin de evitar confusiones y poder cumplir
con lo acordado.
- Solicita al cliente que firme hoja en cuadernillo con las condiciones del negocio
- Recuerda al cliente la existencia de la app Kaufmann y la importancia de descargarla
para mantenerse informado
- Genera actividad en CRM para comunicar fecha de entrega final del vehículo.
6.9. Entrega del vehículo
La Entrega del Vehículo es una instancia fundamental para el cliente en el proceso de
compra. Es un momento donde se confirman sus expectativas positivas sobre la Marca.
Una experiencia positiva con la entrega del vehículo tiene un efecto positivo en el negocio
de servicio, la probabilidad de que el cliente acuda a la empresa para efectuar las revisiones
y a servicio PostVenta, aumenta en un 40%, lo mismo ocurre con la probabilidad de
recomendación y recompra*.
Por eso resultan críticos tanto el cumplimiento de plazos, como el interés, competencia y
amabilidad percibidos por el cliente en el momento de la entrega.
Independientemente de que la entrega tenga lugar en nuestra sucursal o en las
instalaciones del cliente, debemos hacer que este momento sea especial: el cliente debe
notar que compartimos su satisfacción y entusiasmo.
- Cifras según el estudio “Experiencia de compra” de JD Power.
Informar siempre al cliente:
Debido a la cantidad de interacciones con diferentes áreas internas para entregar un
vehículo y a las diversas etapas de aprobación por las que es necesaria pasar, es vital que
mantengas informado al cliente sobre el estado de avance en la entrega de su vehículo.
Se proactivo y transparente frente al cliente durante el proceso de espera de entrega del
vehículo en función de las etapas y plazos informados durante el cierre de negocio. “Hazte
cargo de tus promesas” independiente si el cumplimiento es responsabilidad de otro.
6.9.1. Protocolo para agendar entrega:
Correo para agendar Proceso de Entrega Completo:
Estimado XXXXXX,
De acuerdo a lo conversado, realizaremos el proceso de entrega de su (modelo de vehículo)
el día XXX a las HH:MM hrs en la sucursal XXXXXX ubicada en XXXXXXXXXXXX.

Le recuerdo que la entrega contempla la presentación de diferentes aspectos técnicos y de
seguridad. Por lo que es necesario que considere alrededor de 45 minutos en su agenda
para que efectuemos este proceso.
Quedo atento a su confirmación para agendar la entrega.
Saludos ,
Corrreo para agendar proceso de Entrega Breve:
Estimado XXXXXX,
De acuerdo a lo conversado, realizaremos el proceso de entrega de su (modelo de vehículo)
el día XXX a las HH:MM hrs en la sucursal XXXXXX ubicada en XXXXXXXXXXXX.
Considerando que usted no dispone del tiempo necesario para realizar el proceso de
entrega completo, realizaremos una entrega breve que incluye los aspectos técnicos
mínimos a revisar, contemplando entre ellos, temas de seguridad
Es necesario que considere disponer de 15 minutos para este proceso.
Quedo atento a su confirmación para agendar la entrega.
Saludos ,
Preparación del vehículo:

- Teniendo claridad y acuerdo de la fecha y hora de entrega, ocúpate de contar con la
unidad en perfectas condiciones.
- Realiza previamente un chequeo visual externo, comprobando que el vehículo se
encuentre sin daños, piquetes ni rayones, verifica estado y presión de neumáticos y
que todos los accesorios de seguridad y equipamiento del vehículo estén presentes.
- El mismo chequeo se debe realizar en el interior del vehículo, comprobando que el
habitáculo se encuentre en perfecto estado y de acuerdo a la ficha de venta.
- Si el vehículo no puede ser entregado por daños detectados en el proceso previo a la
entrega o efectuarse retrasos en el plazo de entrega, comunica al cliente mediante
correo o vía telefónica siguiendo el protocolo sugerido
6.9.2. Protocolo sugerido para reagendar entrega
“Estimado XXXXXXX, le comento que durante el proceso de preentrega, detectamos
algunos detalles en su vehículo por lo cual no se encuentra en condiciones de ser entregado
en la fecha acordada.
Le informaré una vez revisados estos detalles para reagendar la fecha de entrega.
Estaré pendiente de su caso con el objetivo de acelerar el proceso y concretar la entrega a
la brevedad.
Le pido disculpas por las molestias que esto pudiese ocasionar.
Lo mantendré informado por esta vía”
Saludos,
*Reforzar esta comunicación con un llamado telefónico

Preparar la documentación:

- Debes contar con toda la documentación necesaria a entregar al cliente y haber
realizado los trámites administrativos pertinentes.
Recepción y Saludo
- El cliente debe ser atendido personalmente por el vendedor en el lugar acordado.
- Realiza una breve explicación del proceso de entrega que se llevará a cabo, detallando
el tiempo que tomará y temas a revisar.
6.9.3. Protocolo sugerido para la recepción en el proceso de entrega
Junto a la llegada del cliente, ponte de pie y saludar dando la mano de manera firme
acompañando el saludo con una sonrisa y mirando a los ojos.
“Buenos días/ tardes, bienvenido a Kaufmann. Lo estábamos esperando”
(Se entabla conversación natural entre el vendedor y el cliente)
Para los casos en que se realizará el proceso de entrega completo:
“Acompáñeme, (se dirigen a la zona de entrega) daremos inicio a la entrega de su
vehículo, el proceso tomará alrededor de 45 min. Esto contempla la presentación del
vehículo, la revisión de la documentación y la resolución de sus dudas”.
Para los casos en que el cliente indique que no cuenta con el tiempo para el proceso de
entrega completo, se realizará el proceso de entrega “breve” 15 min
“Don XXXXXX debido a que usted indicó que no cuenta con el tiempo para efectuar
el proceso de entrega completo; le haré una breve presentación de los aspectos que
necesariamente debemos revisar, contemplando temas de seguridad, Acompáñeme,
(se dirigen a la zona de entrega) daremos inicio a la entrega de su vehículo, el
proceso tomará alrededor de 15 min. Esto contempla la revisión de la documentación
y la presentación breve del vehículo”
Entrega de documentación
- Invita al cliente y su acompañante a tomar asiento frente a ti en tu escritorio.
- Ofrece servicio de cafetería al cliente y acompañante.
- Procede a revisar la documentación incluida en carpeta corporativa: (seguir protocolo
de entrega de documentación)
Documentación a incorporar: (para vehículos comerciales)
- Tarjeta de presentación del vendedor (obligatorio)
- Factura (obligatorio)
- Certificado de homologación (obligatorio)
- Solicitud de Primera Inscripción (opcional)
- Permiso de circulación (opcional)
- Sello Verde (opcional)
- Revisión técnica (opcional)
- Contratación de seguro en casos solicitados (opcional)
- Copia de rendición con detalle de gastos de inscripción (opcional)
- Díptico informativo de cursos de capacitación (obligatorio)
- Carta de Bienvenida a Kaufmann (obligatorio)
- Formulario de garantía (obligatorio)
- Acta de entrega firmada por el cliente una vez recepcionado el vehículo (obligatorio)
- Solicita firma de memo al cliente que acredite la recepción del homologado y factura.
- Toda la documentación debe ser explicada, debidamente firmada por el cliente e
incluida en la carpeta corporativa.
6.9.4. Protocolo para entrega de documentación
“Bien Don XXXXXXXX, comenzaremos con la entrega de la documentación
correspondiente”
“Luego, le haré la presentación del vehículo, donde revisaremos algunos aspectos técnicos
que le serán útiles para su uso y resolveremos las dudas que puedan surgir”
6.9.5. Protocolo de entrega díptico de capacitación
“Kaufmann a través de su centro de entrenamiento, dispone de cursos de capacitación
gratuitos para usted o la persona que usted designe.
Disponemos de cursos de operación y mantenimiento básico de su vehículo, los cuales le
ayudarán a sacar el mejor provecho de este.
La duración del curso es de 8 horas, en este díptico encontrará información y contactos
para agendar el curso cuya vigencia es de 3 meses a partir de la fecha de entrega del
vehículo.
Le haremos envío también de videos tutoriales a su correo o whatsapp como apoyo para
que pueda ir familiarizándose con su nuevo vehículo” ¿Qué medio le es más fácil?
Registrar correo whatsapp para enviar los videos tutoriales
6.9.6. Protocolo pago vehículo
- Acompaña al cliente a realizar el pago a la caja. (en el caso de realizar el pago el mismo
día de la entrega)
- Procura tener los trámites de financiamiento y pago ya revisados con el fin de agilizar
el proceso de pago.
- Preocúpate de que exista privacidad al momento del pago.
“Don XXXXXX, lo acompaño a la caja para que realice el pago”

Entrega física del vehículo

- Una vez presentada y explicada la documentación, ponte de pie e invita al cliente a la
presentación del vehículo.
- Procura generar una atmósfera agradable en la zona de entrega (iluminación, música
ambiental, aroma, etc) evita interrupciones creando un ambiente grato para el cliente
- Considerar la receptividad del cliente ante la entrega de información técnica y su
conocimiento técnico previo.
- Haz entrega formal de las llaves
Realizar la presentación del vehículo contemplando:
- Énfasis en aspectos de seguridad.
- Énfasis en los elementos distintivos de diseño
- Énfasis en ventajas respecto a la competencia
- Explicación en profundidad de innovaciones técnicas que podrían terminar en visitas
innecesarias a taller por desconocimiento del producto.
6.9.7. Protocolo de presentación del vehículo
“Don XXXXXX ahora haremos la entrega formal de su (MODELO DE VEHÍCULO)
haciendo un recorrido ordenado por sus principales componentes mientras le voy
explicando su propósito y función”
Se acercan al vehículo y comienza el recorrido de presentación del vehículo en 7 pasos
denominado Walk Around.
Firma Acta de Entrega y dar a conocer Post Venta:
- En conjunto con el cliente, chequea que los componentes indicados en el acta de
entrega se encuentren presentes en el vehículo y solicita su firma de conformidad.
- Adjuntar el acta de entrega a la carpeta con documentación.
Introducir al cliente al mundo de Post Venta:
- Explicar sistema de agendamiento en línea y frecuencia de mantenciones.
- Aclarar que la primera mantención se efectúa a los 10.000 ó 20.000 kms o al año de
uso (lo primero que se cumpla)
- En conjunto con el cliente y mostrando la pantalla de tu computador, agenden la
primera mantención (con fechas tentativas) explicando que podría variar y reagendarse
según su necesidad.
- Acompaña al cliente al área de Servicio y presentarle al jefe de taller con nombre y
apellido.
- Despídete y agradece su preferencia.

6.9.8. Protocolo introducción Post Venta.
“Una vez llegado el momento de realizar su primera mantención, debe agendar su hora de
atención en línea contactándose al número de teléfono +562 2 481 4848 o ingresando a la
página web de Kaufmann. ([www.kaufmann.cl](http://www.kaufmann.cl/)). De esta forma podrá reservar su hora a taller
y permitirnos atenderle de forma exclusiva y programada”
“Iremos a la zona de servicio, para presentarle al jefe de taller y/o al equipo de asesores de
servicio que lo atenderán en esta sucursal cuando requiera hacer ingreso a servicio. De
esta forma estará familiarizado con nuestro equipo de post venta desde un comienzo”
Don XXXXX, le presento a XXXX XXXX jefe de taller, sucursal XXXX,
“Hoy le estamos haciendo entrega de su nuevo (modelo del vehículo) y queremos que
conozca a nuestro equipo de servicio”
Asesor de servicio saluda dando la mano y bienvenida al nuevo cliente e indica que en el
tarjetón van sus datos de contacto.
Dentro de los próximos días será contactado por una ejecutiva quien le realizará una
encuesta para conocer su opinión sobre nuestro proceso de venta. Para nosotros es de
gran ayuda conocer su opinión. Le agradecería que pudiera tomar unos minutos de su
tiempo para contestarla.
“¿Hay algo más en que le pueda ayudar?”
“No se olvide que en la tarjeta de presentación que le entregué están mis datos de contacto,
quedo disponible para asesorarle en lo que necesite”
Vendedor se pone de pie, se despide dando la mano de manera firme y mirando a los ojos
con una sonrisa.
“Don XXXX, lo felicitamos por su nuevo vehículo, agradecemos su preferencia y le damos
la bienvenida a Kaufmann. ¡Hasta pronto!”
6.10. Seguimiento a la venta
El seguimiento de la venta busca mantener una relación positiva y de largo plazo con el
cliente y lograr su lealtad con nuestra empresa.
El objetivo del seguimiento es detectar el nivel de satisfacción del cliente, ofrecer soluciones
ante posibles necesidades que hayan podido surgir y fidelizar para construir una relación
de largo plazo.
El contacto en los primeros días refuerza la decisión del cliente. Por ello, el cliente agradece
que el vendedor de Kaufmann se contacte con él.

Además, debes informarle regularmente sobre lo que le puedes ofrecer: novedades en
servicio, nuevos modelos, ampliación de instalaciones, eventos, etc.

- Registra en CRM una vez efectuada la venta y entrega del vehículo, de esta forma, el
sistema te informará en un plazo definido que es necesario volver a contactar al cliente.
- Llamada post-entrega: Llamada a los 45 días hábiles de la entrega para comprobar
satisfacción.
- Indagar grado de satisfacción del cliente con el vehículo nuevo y los servicios
contratados
- En el caso de insatisfacción, busca soluciones
- En el caso de satisfacción, pide referencias
- Llama cuando se aproxime el momento de la renovación de productos financieros
- Muestra al cliente que mantienes el mismo nivel de interés en él que en la fase de la
venta, por ejemplo, preguntando por la evolución de su negocio o actividad profesional.
Beneficios de hacer un seguimiento de las ventas
- Proporciona un recuerdo agradable para rematar el proceso de venta
- Reafirma al cliente que la relación con el vendedor es cercana y de largo plazo
- Es un componente positivo y fundamental en el proceso de fidelización
- Confirma al cliente su decisión de compra y contrarresta la posible incertidumbre
- Confronta y permite solucionar potenciales insatisfacciones
- Tiene un impacto positivo en las encuestas de satisfacción (Vehículo a su medida y
CSI)
- Ayuda a mejorar la disposición a realizar futuras compras.
- Genera recomendación boca a boca.
1. Modificaciones
Versión 01.
En punto 4 Documentos Aplicables, se elimina Brochure corporativo de productos y
servicios Kaufmann.
En punto 6 Medios de apoyo a utilizar para entregar al cliente y reforzar tu visita, se elimina
Brochure corporativo de productos y servicios Kaufmann.
Punto 6.9.3 en documentación a incorporar para vehículos comerciales se elimina; Tarjetón
de presentación de Servicio (Taller) con instructivo de agendamiento, Pauta de
mantenimiento (obligatorio).
Punto 6.9.7, apartado “Introducir al cliente al mundo de Post Venta”, elimina punto
relacionado a mostrar al cliente el tarjetón de servicio.
Punto 6.9.8 se eliminan los puntos relacionados a la entrega de tarjetón informativo con
contactos.