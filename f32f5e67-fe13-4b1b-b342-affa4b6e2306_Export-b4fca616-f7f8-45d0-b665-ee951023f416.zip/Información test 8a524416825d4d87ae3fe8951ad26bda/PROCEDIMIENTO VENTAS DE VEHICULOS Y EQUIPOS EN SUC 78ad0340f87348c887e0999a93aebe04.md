# PROCEDIMIENTO VENTAS DE VEHICULOS Y EQUIPOS EN SUCURSALES

1. OBJETIVO
Este procedimiento tiene el objetivo de establecer los lineamientos para las acciones que
permitan detectar nuevos clientes y nichos de negocio y describir el proceso general de ventas
de vehículos y equipos en toda la Red de Sucursales del Grupo Kaufmann, incorporando
controles de Seguridad y Salud Ocupacional (SSO) y Medio Ambiente para los colaboradores.
2. ALCANCE
Este procedimiento aplica para todas las sucursales del país
3. RESPONSABILIDADES
Ejecutivo de Ventas: proponer acciones para materializar estrategia de la compañía.
Informarse periódicamente a través de los medios de comunicación como revistas, informes,
diarios, internet, de las variaciones que pueda sufrir el mercado. Asegurarse de que el vehículo
a vender está disponible. Debe reportar acciones realizadas diariamente, canalizando dicha
información a través de Sistema CRM. Es responsable de realizar la venta de vehículos (nuevos
y semi-nuevos) correspondientes a su sucursal y dar el primer visto bueno a la ficha de venta,
debe generar y/o solicitar la documentación referente a la venta al cliente.
Ejecutivo de Ventas de Equipos Tremac: es responsable de realizar la venta de equipos,
apoyado por la gestión de los Ejecutivos de Ventas de Vehículos.
Gerente de Sucursal, Subgerente Zonal o Jefe de Ventas: comunicar Estrategia de Ventas,
para que Prospección esté alineada; así mismo explica las políticas de atención a nuevos
clientes. Es responsable de dar el segundo visto bueno a la ficha de venta y dejarla en estado
“Liberada” (para venta de automóviles revisar procedimiento P-KFT-02 “Planificación y entrega
de automóviles”).
Subgerente o Jefe de Administración y Finanzas de Sucursal: es responsable de dar el
tercer visto bueno y de dejar la ficha de venta en estado “Vigente”.
Asistente Administrativa de Ventas o Asistente de Gerencia: Apoyar logísticamente a
Ejecutivos de Ventas, atender a clientes en ausencia del Ejecutivo de Ventas, tramitar
documentación, elaborar informes de ventas. Es responsable de revisar que toda la
documentación esté firmada, que las retomas sean finiquitadas y que los abonos, detallados en
cada negocio, se hayan realizado efectivamente y estén confirmados los fondos (en caso de
cheques, vale vista, depósitos o transferencia electrónica).
Asistente Comercial, Asistente Administrativa de Ventas, Asistente de Gerencia o
Ejecutivo de Ventas: Revisar las unidades Nuevas y Usadas y sus accesorios (los que detalle
el Acta de Recepción del vehículo) al momento de recepcionarlos, despacharlos a otra Sucursal
y entregarlos a los clientes (los que detalla el Acta de Entrega del Vehículo), debe tramitar la confección de escritura con notaría y solicitar la firma a cliente. Documentación solicitada por
ADR.
Asistente Administrativo, Recepcionista de Vehículos o Ejecutivo de Ventas dueño del
negocio: es responsable de solicitar los peritajes de los vehículos que los clientes entregan en
parte de pago (venta con retoma).
Comité de Crédito: Aprobar, rechazar o condicionar solicitud de financiamiento considerando
políticas de la empresa. Realizar las labores descritas en el documento P-ADR-01
“Procedimiento Evaluaciones de Crédito para financiamiento de vehículos”
4. DOCUMENTOS APLICABLES
4.1. P-ADV-01 “Procedimiento de Facturación de Venta de Vehículos Utilitarios”.
4.2. P-ADV-02 “Procedimiento de cálculo y emisión de créditos por ventas o leasing
financieros u operativos”.
4.3. P-ADV-04 “Procedimiento de emisión de contratos por créditos y constitución de
garantías”.
4.4. P-KFT-02 “Planificación y entrega de Automóviles”.
4.5. P-ADR-01 “Procedimiento Evaluaciones de Crédito para financiamiento de vehículos”.
4.6. P-SIG-03 “Salidas no conformes”
5. TERMINOLOGÍA
5.1. Retoma: Vehículo usado que el cliente deja en parte de pago para adquirir un vehículo
con la empresa
5.2. CAV: Certificado de Anotaciones Vigente
5.3. RNVM: Registro Nacional de Vehículos Motorizados
5.4. ADR: Análisis de Riesgo
5.5. SSO: Seguridad y Salud Ocupacional
5.6. SIG: Sistema Integrado de Gestión
6. EQUIPOS Y HERRAMIENTAS
6.1. PC / Notebook.
6.2. Impresora / Fotocopiadora
6.3. E-mail.
6.4. Teléfono móvil o fijo.
6.5. Sistema SAP.
6.6. Sistema Legados.
6.7. Sistema CRM
6.8. Sistema Fiori
4. ACTIVIDADES DEL PROCEDIMIENTO
Existen tres canales que pueden conducir a una venta en una Sucursal:
a) Potencial cliente es contactado por Ejecutivo de Ventas, como resultado de la
planificación realizada por el Área de Ventas para captar nuevos negocios
b) Cliente fidelizado con Kaufmann es contactado por vendedor para ofrecer nuevos
vehículos
c) Cliente visita la Sucursal interesado en algún vehículo.
7.1 POTENCIAL CLIENTE ES CONTACTADO POR EJECUTIVO DE VENTAS
El Gerente, Subgerente o Jefe de Ventas de Sucursal debe dar a conocer a su fuerza de venta
las características del mercado, teniendo presente cual o cuales son la cuotas correspondientes
a Kaufmann.
Según la o las participaciones, definirá en conjunto con los Ejecutivos de Venta el número y tipo
de cliente a visitar.
Se debe definir cuanto tiempo y cantidad de clientes deben visitarse a modo de mantención de
la cartera, teniendo presente que la cartera de cliente activos debe estar en constante
actualización.
Cuando el potencial cliente es contactado por el Ejecutivo de Ventas y se encuentra interesado
en adquirir un vehículo, este deberá ser ingresado al sistema CRM como nuevo cliente.
Posterior a esto, se podrá generar una Oferta.
7.2 CLIENTE FIDELIZADO ES CONTACTADO POR EJECUTIVO DE VENTAS
En este caso, el cliente es contactado por un Ejecutivo de Ventas, ya sea para ofrecer nuevos
vehículos o bien, por algún mensaje entregado por el cliente al call center. En cualquiera de las
dos situaciones, se procede de acuerdo al punto 7.4 de este documento.
7.3 CLIENTE VISITA SUCURSAL INTERESADO EN VEHÍCULO
Dependiendo el tipo de cliente que asista a la Sucursal, será el camino que el Ejecutivo de
Ventas deberá tomar para concretar una posible venta.
Si el cliente está fidelizado, el Ejecutivo de Ventas deberá crear la oferta en el Sistema Legados
a través de CRM y entregársela al cliente.
Si se trata de un cliente nuevo, deberá ser ingresado al sistema CRM como nuevo cliente por
el Ejecutivo de Ventas.

7.4 VENTA DE VEHÍCULOS Y EQUIPOS
7.4.1 SOLICITUD DE ANTECEDENTES COMERCIALES
El Ejecutivo de Ventas debe solicitar antecedentes comerciales al cliente, sólo
cuando éste requiere de financiamiento a través de nuestra empresa.
Los documentos que se deben solicitar a los clientes se encuentran detallados
en el Simulador de Crédito del Sistema Legados.
7.4.2 CREACIÓN DE LA FICHA DE VENTAS
El Ejecutivo de Ventas debe generar la oferta de vehículo a vender y, si la Oferta
es aceptada por el cliente, debe crear la Ficha de Venta en el Sistema Legados.
Los antecedentes y detalles de este proceso, se encuentran señalados en el
documento P-ADV-01 “Procedimiento de Facturación de Venta deVehículos
Utilitarios”.
7.4.3 CONDICIONES DE VENTA
Existen varios tipos de ventas, estas son:
a. Venta Contado: En este tipo de venta, el cliente realiza pago del vehículo o
equipo con Cheque al día, Vale Vista, Transferencia Electrónica, Depósito
Bancario, Tarjeta Crédito, Tarjeta Debito u Orden de Compra (emitidas por
Instituciones Públicas reconocidas por el Estado o emitidas por Empresas de
Leasing externo).
b. Venta al Crédito: Generalmente es un crédito directo que financia sobre el 70
del valor del vehículo, con plazos entre 12, 24, 36 y 48 cuotas , y éste se debe
respaldar con un Reconocimiento de Deuda Notarial, Prenda y Prohibición y
Garantía Adicional, si corresponde. Las ventas al crédito serán tratadas de
acuerdo al documento P-ADR-01 “Procedimiento Evaluaciones de Crédito
para financiamiento de vehículos”.
c. Venta Leasing: Existen dos tipos de Leasing: Interno y Externo. Ambos están
normados, en los documentos P-ADV-02 “Procedimiento de cálculo y emisión
de créditos por ventas o leasing financieros u operativos” y P-ADV-04
“Procedimiento de emisión de contratos por créditos y constitución de
garantías”.
d. Venta con Retoma:

1. Cuando el Cliente compra un vehículo nuevo o usado y deja un vehículo
en parte de pago como abono para la compra, el vehículo es comprado o retomado por Empresas Kaufmann. Dependiendo de cada caso, la
Retoma se realiza a través de Comercial Kaufmann S.A., Inversiones
Kaufmann S.A. o La Estrella Leasing Ltda.
2. El Ejecutivo de Ventas, Encargado de Vehículos Usados y/o Encargo de
Peritaje designado por Taller, debe revisar físicamente el vehículo a
recibir en Parte de Pago y solicitar a la Asistente Administrativa de Ventas
y/o Asistente de Gerencia tramitar el Certificado de Multas, Certificado de
Anotaciones Vigentes y Multas en Autopistas, de esta forma corrobora
que el vehículo a recibir no tenga Prohibiciones, Prendas o Embargos ni
Partes Pendientes, en caso de que esto no se cumpla deberá pedir VºBº
gerencial para proceder a la aceptación del vehículo.
3. El vehículo se envía a Peritaje Técnico al taller de la sucursal, donde
llenando un documento formato, se detallan los valores de las
Reparaciones a realizar; todo esto previamente autorizado por el Gerente
de la Sucursal.
4. Para el caso de automóviles, se solicita a la Subgerencia Comercial de
Vehículos Usados y/o Seminuevos el valor de Retoma del Vehículo,
restando los valores del Peritaje Técnico referente a reparaciones,
posterior a la revisión del taller (Definición de Precio de Compra). Para
camiones y buses, se solicita al Área de Vehículos Usados el valor
referencial de retoma del Vehículo, pero es la Gerencia de la Sucursal
quién determina el precio final de Retoma.
5. Con todos estos antecedentes, División Usados o Gerencia de Sucursal,
según corresponda, fija el Precio de Compra del Vehículo y se procede a
confeccionar los Contratos de Compra y/o Facturas, para finiquitar la
Retoma correspondiente. El Área de Administración de Ventas de cada
Sucursal es el que gestiona y finiquita las retomas, luego de tener todos
los antecedentes necesarios.
6. El Ejecutivo de Ventas es responsable de gestionar y entregar toda la
documentación necesaria para finiquitar la Retoma referida, que será
abonada a una venta. El Asistente Administrativo de Ventas guía, apoya
y supervisa el proceso.
e. Venta Vehículo Usado:
2. Cliente solicita a Ejecutivo de Ventas un vehículo usado, quién realiza la
oferta, según disponibilidad de stock en el Sistema Legados.
3. Ejecutivo de venta confecciona ficha de venta con todos los VºBº respectivos, verifica que la documentación del vehículo esté al día y los
abonos correspondientes estén confirmados para proceder a enviar, al
Área de Administración de Ventas, Contrato de Venta con firma de cliente
autorizada ante notario. Ésta última Área se encarga de obtener firmadel
contrato de venta con Gerente que cuente con autorización vigente,
cancelar y efectuar Solicitud de Transferencia en RNVM para que el
vehículo usado quede a nombre del cliente.
f. Venta con vehículo en consignación:
4. Esta modalidad de venta consiste en que el cliente entrega en depósito
un vehículo en la Sucursal para la venta por un período determinado; esto
se formaliza a través de un Contrato de Consignación que es
confeccionado por el Asistente Administrativo de Ventas, en el que se
estipulan las condiciones, tales como comisiones y fecha vencimiento del
contrato.
5. El vehículo se envía a Peritaje Técnico al taller de la sucursal, donde
llenando un documento formato, se detallan los valores de las
Reparaciones a realizar; todo esto previamente autorizado por el Gerente
de la Sucursal. Una vez que se realiza el Peritaje, el cliente debe aceptar
las reparaciones que se le harán al vehículo para dejarlo en exhibición y
el precio de venta propuesto (revisar con comerciales).
6. Estas unidades son tratadas internamente como stock de vehículos
usados diferenciándose con la palabra “Vehículos Usados en
Consignación” y se designan en Sistema Legados con un número de
pedido y la letra “U” (utilizada para todo tipo de vehículo seminuevo
recibido en la sucursal).
7. Es importante señalar, que la Sucursal puede recibir vehículos en
consignación, sin que esto implique necesariamente la venta de un
vehículo por parte de Kaufmann.
g. Aprobación de la Ficha de Ventas:
8. Una vez definido el Tipo de Venta, aprobado el Crédito o Leasing y que la
Ficha de Venta contenga todos los Vistos Buenos de Autorización Digital
en el Legados, el Ejecutivo de Ventas informa a Asistente de
Administración de Ventas o Asistente de Gerencia para que solicite VºBº
de facturación. El Asistente verifica que toda la información de ficha de
venta sea la correcta y, una vez efectuadas las correcciones (si es que las
hubiese), se solicita VºBº de facturación a la Gerencia de Administración
de Ventas.

h. Facturación:

1. La factura es emitida por la Administración de Línea de la Gerencia de
Administración de Ventas y se envía a la Sucursal; se debe adjuntar
Garantía, Certificado de Primer Servicio (si se hubiera realizado),
Certificado de Compromiso de Capacitación y Certificado de
Homologación de Gases (en el caso de los Vehículos Nuevos), con este
documento, nuestro cliente realiza la Inscripción del Vehículo en el
R.N.V.M., tramita la Revisión Técnica (si corresponde en vehículos
usados) y el Permiso de Circulación. El Certificado Original queda en
poder del cliente.
2. Al igual que el Certificado de Homologación, la Factura y el resto de los
documentos sólo se solicita una vez que estén todos los V°B° de las Áreas
involucradas.
3. La Facturación de Vehículos Usados es emitida por la Gerencia de
Administración de Ventas, quién gestiona la documentación de venta
(contado o crédito). Esta Gerencia realiza la transferencia, gestiona la
firma del Gerente de la División Comercial correspondiente de los
Contratos de Venta y Arrendamiento, posteriormente remite la
documentación a la Sucursal para proceder a entregarla al cliente.
7.5 INFORMACIÓN DE SSO Y MA ASOCIADOS A LA OPERACIÓN ADMINISTRATIVA.
Existen riesgos asociados a la labor, los que son detallados en las matrices aplicables a cada
área.
Existen aspectos e impactos ambientales asociados a la labor, los que son detallados en las
matrices de aspectos e impactos ambientales de cada área.
4. REGISTROS
8.1 Ficha de Venta.
8.2 Oferta.
8.3 Factura.
8.4 Contrato de Venta
8.5 Contrato de Compraventa.
8.6 Contrato de Reconocimiento de Deuda.
8.7 Contrato de Arrendamiento.
8.8 Fianza Solidaria o Garantías Adicionales
8.9 Contrato de Consignación
8.10 Acta de Recepción/Entrega Vehículo
8.11 Guía de Despacho

8.12 Certificado de Capacitación
8.13 Garantía de Vehículo
9. ANEXOS
N/A
10. MODIFICACIONES DEL DOCUMENTO
10.1. Se incorpora información de MA asociada a la operación
10.2. Se agrega sistema Fiori en punto 6 y se quitan los memorandos de intranet desde el punto 4.